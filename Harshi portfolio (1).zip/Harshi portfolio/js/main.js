//Header Scroll

document.addEventListener("DOMContentLoaded", function() {
    // Get the "Get a look on CV" button
    var cvButton = document.querySelector(".main-btn[href='#']");

    // Add click event listener
    cvButton.addEventListener("click", function(event) {
        // Prevent the default action of the link
        event.preventDefault();

        // Redirect to your resume PDF
        window.open("Harshita-Mehandiratta_resume_newly_updated (1).pdf", "_blank");
    });
});


//